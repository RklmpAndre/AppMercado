package view;

import entity.Carrinho;
import persist.CarrinhoDAO;

/**
 *
 * @author andre; arthur
 */
public class App {

    public static void main(String[] args) {
        new TelaLogin().setVisible(true);
    }
}
